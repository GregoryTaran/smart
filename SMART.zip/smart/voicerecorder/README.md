# 🎙️ VoiceRecorder — Audio Capture & Segmenting Core

**VoiceRecorder** — это модульный веб-диктофон с поддержкой реального времени, построенный на Web Audio API и AudioWorklet.  
Он умеет:
- захватывать звук с микрофона (с отключаемыми фильтрами AGC, AEC, NS),
- применять ручной гейн (усиление),
- визуализировать уровни громкости,
- нарезать поток на куски (2 сек) и собирать итоговый WAV-файл.

---

## 📁 Структура проекта

/voicerecorder
├── voicerecorder.html ← основная страница
├── voicerecorder.js ← главный контроллер UI
├── voicerecorder.css ← стили интерфейса
├── /audiocore
│ ├── sv-audio-core.js ← ядро: микрофон + гейн + worklet
│ ├── recorder.worklet.js← AudioWorkletProcessor (снимает чанки Float32)
│ ├── wav-segmenter.js ← режет поток на куски по 2 сек (с паддингом)
│ └── wav-assembler.js ← собирает итоговый WAV из сегментов
├── /mic-indicator ← визуализация громкости
/uuid ← генерация user/session id

yaml
Копировать код

---

## ⚙️ Как работает

1. **Захват:**  
   `SVAudioCore` подключает микрофон и формирует цепочку  
MediaStream → GainNode → AudioWorklet

markdown
Копировать код
Гейн (`VR_MANUAL_GAIN`) усиливает сигнал.  
Встроенные фильтры (эхо/шумы/автогейн) можно включать или выключать.

2. **Работа с Worklet:**  
`recorder.worklet.js` получает аудиопоток маленькими блоками (по 128 сэмплов)  
и передаёт их в основной поток через `port.postMessage`.

3. **Нарезка:**  
`WavSegmenter` собирает эти чанки в **ровные сегменты по 2 сек**,  
а последний при `stop()` дополняет тишиной, чтобы длина совпадала.  
Каждый сегмент можно сразу отправлять на сервер.

4. **Сборка:**  
`WavAssembler` принимает список сегментов и формирует финальный WAV-файл.  
Может при необходимости ресемплировать в `targetSampleRate` (например, 16 кГц).

5. **UI:**  
`voicerecorder.js` управляет кнопками **Start / Pause / Stop**,  
обновляет статус, подключает индикатор громкости и скачивает итоговый файл.

---

## 🧩 Настройки аудио (sv-audio-core.js)

```js
const VR_ECHO_CANCELLATION = false;  // Acoustic Echo Cancellation
const VR_NOISE_SUPPRESSION = false;  // Noise Suppression
const VR_AUTO_GAIN_CONTROL = false;  // Auto Gain Control (мы его отключаем)
const VR_MANUAL_GAIN      = 1.3;     // Ручной коэффициент усиления
🚀 Как запустить
Размести всё на любом локальном или удалённом сервере (нужен HTTPS для микрофона).

Открой /index.html.

Нажми «Открыть Voice Recorder» → появится интерфейс.

Start — запись, Pause — пауза, Stop — остановка и скачивание WAV.

🧠 Архитектура данных
scss
Копировать код
🎤 Mic input
   ↓
[SVAudioCore] → GainNode(1.3×)
   ↓
[AudioWorklet] → Float32 chunks
   ↓
[WavSegmenter] → 2 сек PCM Int16 сегменты
   ↓
[WavAssembler] → Итоговый WAV (Blob)
🔧 Возможные расширения
✅ Отправка сегментов на сервер в реальном времени

✅ Поддержка Whisper API / Speech-to-Text

⚙️ Визуальный гейн (для индикатора)

🎚️ Настраиваемый сегментный размер (1–5 сек)

🎨 UI/PWA-обёртка под мобильные устройства