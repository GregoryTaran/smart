# AudioCore — захват, нарезка и сборка аудио (Web Audio API)

Этот каталог содержит «сердце» звукового стека: подключение микрофона, базовую обработку (гейн, AEC/NS/AGC — опционально), передачу PCM-кадров через AudioWorklet, нарезку на сегменты и сборку итогового WAV.

## 📁 Состав каталога

```
audiocore/
├─ sv-audio-core.js      # Ядро захвата: MediaStream → GainNode → AudioWorklet
├─ recorder.worklet.js   # AudioWorkletProcessor: отдаёт Float32 кадры в главный поток
├─ wav-segmenter.js      # Режет поток на ровные 2s сегменты (последний можно допадить тишиной)
└─ wav-assembler.js      # Склеивает список сегментов в финальный WAV (опц. ресемплинг)
```

## 🔌 Общий поток сигнала

```
[ getUserMedia ]
      │  (применяем AEC/NS/AGC — флаги из sv-audio-core.js)
      ▼
MediaStreamSource ──► GainNode(VR_MANUAL_GAIN) ──► AudioWorkletNode("recorder-processor")
                                               (port.postMessage → Float32 кадры)
      ▼
  (главный поток)
      ▼
WavSegmenter (2s куски Int16 + meta) ──► WavAssembler (большой WAV по запросу)
```

## ⚙️ Настройки захвата (sv-audio-core.js)

Верх файла содержит флаги — «одна точка правды» для поведения браузерного трака:

```js
// =================== VoiceRecorder audio defaults (edit here) ===================
const VR_ECHO_CANCELLATION = false;  // Acoustic Echo Cancellation (AEC)
const VR_NOISE_SUPPRESSION = false;  // Noise Suppression (NS)
const VR_AUTO_GAIN_CONTROL = false;  // Auto Gain Control (AGC)
const VR_MANUAL_GAIN      = 1.3;     // Ручной гейн через GainNode (1.0 = без усиления)
// ===============================================================================
```

- **AEC/NS/AGC** передаются в `MediaStreamTrack.applyConstraints()` и применяются, если девайс/браузер поддерживает.
- **VR_MANUAL_GAIN** задаёт «честное» программное усиление на `GainNode` (влияет и на индикатор, и на запись).

### Быстрый выбор режимов
- 📱 Мобильная речь (естественность): `AGC=false`, `GAIN=1.2–1.4`, `AEC=false`, `NS=false`.
- 🖥️ Ноут с эхом/шумом: `AEC=true`, `NS=true`, `AGC=false`, `GAIN=1.1–1.3`.
- 🧪 Тест «как есть»: всё `false`, `GAIN=1.0`.

## 🧱 API ядра (sv-audio-core.js)

```js
const core = new SVAudioCore(options?);

// Жизненный цикл
await core.init();        // запускает AudioContext, запрашивает микрофон, строит граф, применяет флаги
core.stop();              // стоп графа и стрима
core.destroy();           // окончательная очистка

// Пауза/резюм
core.pauseCapture();
core.resumeCapture();

// Доступ к окружению
const ctx    = core.getContext();  // AudioContext
const stream = core.getStream();   // MediaStream (после Gain/Worklet)

// Обработчики кадров
core.onAudioFrame = (float32MonoFrame) => { /* ваш код */ };
```

> **Важно:** индикатор подключаем к `core.getStream()` — он отображает уже **усиленный** сигнал.

## 🧩 AudioWorklet (recorder.worklet.js)

- Объявляет `registerProcessor('recorder-processor', class extends AudioWorkletProcessor { ... })`.
- В `process(inputs)` берёт из `inputs[0][0]` **моно Float32** блок (обычно 128 семплов), по необходимости микширует в моно, и шлёт в главный поток `this.port.postMessage({ type: 'frame', data: Float32Array })`.
- Производительность: Worklet работает в аудио-потоке, минимизирует лаги и джиттер.

## ✂️ Сегментация (wav-segmenter.js)

Задача: стандартизировать поток в **ровные 2s сегменты** (для дальнейшего стриминга на сервер).

Особенности:
- При потоке из Worklet складывает внутренний «хвост». Как только накапливается `2s`, эмитит сегмент (`pcmInt16`, `sampleRate`, `durationSec`, `seq`).
- На `stop()` поддерживает **два режима**:  
  - `padLastSegment: true` — последний сегмент дополняется **нулями** до 2s (удобно для ровной сетки),  
  - `padLastSegment: false` — последний сегмент эмитится «как есть» (короче 2s).
- Опционально может сразу отдавать `blob` (WAV на сегмент), если `emitBlobPerSegment = true`.

Пример:
```js
import WavSegmenter from './wav-segmenter.js';

const seg = new WavSegmenter({
  sampleRate: audioCtx.sampleRate,
  segmentSeconds: 2,
  normalize: true,
  normalizeTarget: 0.99,
  padLastSegment: true,      // последний всегда ровно 2s (хвост + тишина)
  emitBlobPerSegment: false, // если нужен WAV per сегмент, поставьте true
});

seg.onSegment = (s) => {
  // s: { seq, sampleRate, durationSec, pcmInt16, blob|null }
  // здесь удобно отправлять сегмент на сервер
};
```

## 🧵 Сборка финального WAV (wav-assembler.js)

Принимает сегменты (из Segmenter) и по запросу собирает **большой WAV**.  
Особенности:
- Склейка `Int16` массивов всех сегментов (по порядку `seq`).
- Опциональный **ресемплинг** в `targetSampleRate` (линейная интерполяция; достаточно для диктовки и ASR).
- Возвращает `Blob` (`audio/wav`).

Пример:
```js
import WavAssembler from './wav-assembler.js';

const asm = new WavAssembler({ /* targetSampleRate: 16000 */ });

segments.forEach(s => asm.addSegment(s));

const wavBlob = asm.buildFinalWav();
// Скачать или отправить на сервер
```

## 🔗 Интеграция с контроллером страницы (voicerecorder.js)

Минимальный поток:
```js
// 1) Захват
await core.init();
const sr = core.getContext().sampleRate;

// 2) Сегментация
const segments = [];
const seg = new WavSegmenter({ sampleRate: sr, segmentSeconds: 2, padLastSegment: true });
core.onAudioFrame = (f32) => seg.pushFrame(f32);
seg.onSegment = (s) => segments.push(s);

// 3) Финализация по Stop
seg.stop(); // эмитит финальный (паддед) сегмент
const asm = new WavAssembler();
segments.forEach(s => asm.addSegment(s));
const bigWav = asm.buildFinalWav();
```

## 📱 Замечания по мобильным браузерам

- Некоторые девайсы частично игнорируют запрет AGC/NS/AEC — проверяйте запись ушами.  
- Для стабильной громкости на телефоне часто лучше: `AGC=false`, `GAIN=1.2–1.4`.  
- Если слышен «хрип»/клиппинг — снизьте `VR_MANUAL_GAIN` на 0.1–0.2.

## ⚡ Рекомендации по производительности

- Используйте **AudioWorklet** (уже используется) — `ScriptProcessorNode` устарел.  
- Не создавайте/уничтожайте объекты часто в рендер-цикле; переиспользуйте буферы.  
- Для индикатора уменьшайте `smoothingTimeConstant` до 0.2–0.3, а `fftSize` держите 1024–2048.

## 🧪 Отладка и диагностика

- Проверить реальный `sampleRate`: `core.getContext().sampleRate` (на телефонах часто 48000).  
- Убедиться, что `stopBtn.disabled = false` ставится **после** успешного `core.init()`.  
- Если финальный WAV 1–2 КБ: вы нажали Stop до формирования сегмента и не включили `padLastSegment`. Включите `padLastSegment: true` или жмите Stop после 2s.

## 🧰 Быстрый чеклист перед релизом

- [ ] `VR_AUTO_GAIN_CONTROL = false` (если нужно натуральное звучание).  
- [ ] `VR_MANUAL_GAIN` подобран (1.2–1.4).  
- [ ] `padLastSegment = true` (если требуется ровная сетка сегментов).  
- [ ] HTTPS включён (иначе микрофон может не даваться).  
- [ ] На телефоне тест пройден (качество/громкость/клиппинг).

## 📄 Лицензия
MIT
