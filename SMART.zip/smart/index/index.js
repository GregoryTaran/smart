/* Скрипт только для главной страницы. 
   Пример динамического микромодуля. 
*/

document.addEventListener("DOMContentLoaded", () => {
  // Находим блок .welcome (куда будем добавлять контент)
  const welcome = document.querySelector(".welcome");

  if (welcome) {
    // Создаём элемент микромодуля
    const modBox = document.createElement("div");
    modBox.className = "mod-info-box"; // модульный префикс
    modBox.innerHTML = `
      <h3>🔹 Микромодуль из JS</h3>
      <p>
        Этот текст сгенерирован динамически скриптом <code>index.js</code>.<br>
        Здесь можно подгружать данные, генерировать элементы, 
        или встраивать виджеты.1
      </p>
    `;

    // Вставляем в конец блока welcome
    welcome.appendChild(modBox);
  }
});
