# 📘 SMART VISION — БАЗА ДАННЫХ (Supabase)

---

## ⚙️ Общая структура

Система состоит из четырёх таблиц:

- **levels** — справочник уровней доступа  
- **users** — основная таблица зарегистрированных пользователей  
- **visitor** — таблица анонимных визиторов  
- **auth_vault** — универсальное хранилище артефактов аутентификации  

Все таблицы связаны между собой, построены на **Supabase (Postgres)**, работают без RLS (на этапе тестирования).

---

## 🧩 levels

**Описание:**  
Справочник уровней. Позволяет динамически добавлять/изменять уровни без миграций.

| поле | тип | описание |
|------|-----|-----------|
| level_id | SMALLINT | числовой ID уровня |
| code | TEXT | код уровня (guest, user, paid1...) |
| name | TEXT | имя уровня |
| description | TEXT | описание уровня |
| is_active | BOOLEAN | активен ли уровень |
| sort_order | SMALLINT | порядок отображения |

**Стартовые данные:**

| id | code | name | описание |
|----|------|------|----------|
| 1 | guest | Guest | Анонимный пользователь |
| 2 | user | User | Базовый юзер |
| 3 | paid1 | Paid Tier 1 | Платный уровень 1 |
| 4 | paid2 | Paid Tier 2 | Платный уровень 2 |
| 5 | super | Super User | Администратор |

---

## 👤 users

**Описание:**  
Главная таблица пользователей (зарегистрированные и идентифицированные).  
`level` по умолчанию = **2 (user)**.

| поле | тип | описание |
|------|-----|-----------|
| user_id | UUID | уникальный ID пользователя |
| level | SMALLINT | FK на levels(level_id), по умолчанию 2 |
| created_at | TIMESTAMPTZ | дата создания |
| state | ENUM(active, blocked, pending_verification, deleted) | состояние учётки |
| display_name | TEXT | отображаемое имя |
| avatar_url | TEXT | ссылка на аватар |
| locale | TEXT | язык интерфейса |
| timezone | TEXT | часовой пояс |
| email | TEXT | почта |
| email_verified | BOOLEAN | подтверждён ли email |
| phone | TEXT | номер телефона |
| phone_verified | BOOLEAN | подтверждён ли телефон |
| supabase_user_id | UUID | ID в Supabase Auth |
| google_sub | TEXT | ID в Google |
| apple_sub | TEXT | ID в Apple |
| passkeys | JSONB | список passkey |
| plan_code | TEXT | тариф/план |
| paid_until | TIMESTAMPTZ | срок действия тарифа |
| feature_flags | TEXT[] | активные фичи |
| limits | JSONB | лимиты |
| last_login_at | TIMESTAMPTZ | время последнего входа |
| last_ip | INET | последний IP |
| trusted_devices | JSONB | доверенные устройства |
| linked_visitor_ids | JSONB | связанные визиторы |
| consents | JSONB | согласия пользователя |
| tags | TEXT[] | теги |
| notes | TEXT | заметки |
| deleted_at | TIMESTAMPTZ | дата удаления |

---

## 👀 visitor

**Описание:**  
Каждый посетитель (даже без логина) получает уникальный `visitor_id`.  
Используется для отслеживания и связывания визитов.

| поле | тип | описание |
|------|-----|-----------|
| visitor_id | UUID | уникальный ID визитора |
| level | SMALLINT | FK levels(level_id), по умолчанию 1 |
| first_seen_at | TIMESTAMPTZ | время первого визита |
| landing_url | TEXT | первая страница |
| referrer_host | TEXT | откуда пришёл |
| utm_source / utm_medium / utm_campaign / utm_term / utm_content | TEXT | UTM-метки |
| device_type | TEXT | desktop / mobile / tablet |
| device_class | TEXT | phone / tablet / desktop / tv / bot |
| device_brand / device_model | TEXT | бренд и модель |
| os_name / os_version | TEXT | ОС |
| browser_name / browser_version | TEXT | браузер |
| user_agent_hash | CHAR(64) | хэш user-agent |
| screen_width / screen_height | INTEGER | размер экрана |
| touch_support | BOOLEAN | есть ли тач |
| app_platform | TEXT | browser / pwa / native_app / webview |
| app_name / app_version | TEXT | имя и версия приложения |
| runtime_engine | TEXT | chromium / webkit / gecko / webview |
| display_mode | TEXT | browser / standalone / minimal-ui / fullscreen |
| install_source | TEXT | store / add_to_home / direct |
| geo_country / geo_city | TEXT | страна и город |
| timezone_guess | TEXT | предполагаемый часовой пояс |
| ip_address | INET | IP |
| linked_to_user | BOOLEAN | связан ли с user |
| user_id | UUID | FK users.user_id |
| linked_at | TIMESTAMPTZ | когда связали |
| linked_by | TEXT | способ связи (login_same_device / oauth / etc.) |
| linked_visitor_ids | JSONB | другие связанные визиторы |
| merge_notes | TEXT | пояснение по слиянию |
| tags | TEXT[] | произвольные метки |
| notes | TEXT | заметки |
| retention_ttl_days | INTEGER | срок хранения |
| expire_at | TIMESTAMPTZ | когда запись подлежит удалению |

---

## 🔐 auth_vault

**Описание:**  
Хранилище артефактов (результаты аутентификации, токены, куки, профили).  
Принцип — **“храним как есть”**, без лишнего парсинга.

| поле | тип | описание |
|------|-----|-----------|
| artifact_id | UUID | уникальный ID артефакта |
| user_id | UUID | FK users.user_id |
| provider | TEXT | supabase / google / apple / email / otp / passkey / custom |
| kind | TEXT | session / token / cookie / claims / profile / other |
| payload | JSONB | объект, как пришёл от провайдера |
| created_at | TIMESTAMPTZ | время создания |
| status | TEXT | active / expired / revoked |
| expires_at | TIMESTAMPTZ | срок действия |
| last_seen_at | TIMESTAMPTZ | последний доступ |
| notes | TEXT | комментарий |

---

## ⚙️ Индексы и связи

**Основные индексы:**
- `users`: email, level, state, last_login_at, feature_flags (GIN)  
- `visitor`: user_id, first_seen_at, tags (GIN)  
- `auth_vault`: user_id, provider, kind  

**Связи:**
- `users.level → levels.level_id`
- `visitor.level → levels.level_id`
- `visitor.user_id → users.user_id`
- `auth_vault.user_id → users.user_id`

---

## 🧠 Логика по уровням

| уровень | код | кто это |
|----------|-----|---------|
| 1 | guest | анонимный визитор |
| 2 | user | обычный юзер |
| 3 | paid1 | платный тариф 1 |
| 4 | paid2 | платный тариф 2 |
| 5 | super | администратор / системный доступ |

---

## 🔧 Настройка и работа

1. В Supabase открыть **SQL Editor**  
2. Запустить скрипты по порядку:
   ```bash
   001_create_levels_and_users.sql
   002_create_visitor.sql
   003_create_auth_vault.sql
   ```
3. Проверить таблицы в Table Editor  
4. На Dev RLS **выключен**, всё работает через **service key**  
5. Для теста можно вставить данные:
   ```sql
   INSERT INTO users (user_id, display_name, email)
   VALUES (gen_random_uuid(), 'Greg', 'greg@example.com');
   ```

---

## 🔒 Безопасность

- Dev: RLS **OFF**, фронт работает через backend.  
- Prod: включим RLS поэтапно (auth_vault → users).  
- Никаких токенов в открытом виде — только JSON и сервисный доступ.  

---

## ✅ Итого

- 3 основные таблицы + справочник уровней  
- FK-цепочка полностью целостная  
- Всё хранится в Supabase, с дефолтами и индексами  
- JSONB и GIN позволяют гнуть под любые кейсы  
- Можно писать API хоть завтра 🚀  



